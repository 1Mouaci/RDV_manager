package sample;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Filtrage implements Initializable {
    public Button filtre;
    public DatePicker date;
    public TextField nom;
    public TextField prenom;
    public TextField telephone;
    public Label erreur;
    public RadioButton typeDate;
    public RadioButton typeClient;
    public ListView liste;
    public RadioButton aucun;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        nom.setVisible(false);
        prenom.setVisible(false);
        telephone.setVisible(false);
        date.setVisible(false);
        filtre.setVisible(false);

        List<RDV> ttRdv = Noyeau.rdvs;
        if (ttRdv.size() != 0) {
            Client c;
            for (RDV rn : ttRdv
                    ) {
                if (rn.getDate()!=null) {
                    c = Noyeau.patients.get(rn.getClient_Id());
                    liste.getItems().add("RDV N°" + Noyeau.rdvs.indexOf(rn) + ", pour le patient :" + c.getNom() + " " + c.getPrenom());
                }
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initOwner(Main.stage);
            alert.setTitle("Filtre Vide");
            alert.setHeaderText("Aucun Rendez-vous pour le moment!");
            alert.setContentText(null);
            alert.showAndWait();
        }
    }

    public void choiceBoxClique(){
        if (typeDate.isSelected()){
            nom.setVisible(false);
            prenom.setVisible(false);
            telephone.setVisible(false);
            date.setVisible(true);
            filtre.setVisible(true);
        }else {
            if (typeClient.isSelected()) {
                nom.setVisible(true);
                prenom.setVisible(true);
                telephone.setVisible(true);
                date.setVisible(false);
                filtre.setVisible(true);
            }else{
                liste.getItems().clear();
                nom.setVisible(false);
                prenom.setVisible(false);
                telephone.setVisible(false);
                date.setVisible(false);
                filtre.setVisible(false);

                List<RDV> ttRdv = Noyeau.rdvs;
                if (ttRdv.size() != 0) {
                    Client c;
                    for (RDV rn : ttRdv
                            ) {
                        c = Noyeau.patients.get(rn.getClient_Id());
                        liste.getItems().add("RDV N°" + Noyeau.rdvs.indexOf(rn) + ", pour le patient :" + c.getNom() + " " + c.getPrenom());

                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initOwner(Main.stage);
                    alert.setTitle("Filtre Vide");
                    alert.setHeaderText("Aucun Rendez-vous pour le moment!");
                    alert.setContentText(null);
                    alert.showAndWait();
                }
            }

        }
    }

    public void retourClique() {
        Stage stage = Main.stage;
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("noyeau.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("RDV Manager");
            stage.show();
            root.requestFocus();
        } catch (IOException e) {
        }
    }

    public void filtreClique() {
        erreur.setStyle("-fx-text-fill: #fd001e");

        erreur.setVisible(false);
        liste.getItems().clear();
        if (typeDate.isSelected()) {

            if (!date.getValue().toString().equals("")) {
                List<RDV> rdvNow = new ArrayList(Noyeau.rendezVousDuDateX(date.getValue()));
                Client c;

                if (rdvNow.size()!=0) {

                    for (RDV rn : rdvNow
                            ) {
                        c = Noyeau.patients.get(rn.getClient_Id());
                        liste.getItems().add("RDV N°" + Noyeau.rdvs.indexOf(rn) + ", pour le patient :" + c.getNom() + " " + c.getPrenom());

                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initOwner(Main.stage);
                    alert.setTitle("Filtre Vide");
                    alert.setHeaderText("Aucun Rendez-vous pour cette date !\n");
                    alert.setContentText(null);
                    alert.showAndWait() ;

                }
            } else {
                erreur.setText("Remplire  la date");
                erreur.setVisible(true);
            }
        } else {
            if (nom.getText().equals("") || prenom.getText().equals("") || !verifierNumTel()) {
                erreur.setText("remplire les donnée completement");
                erreur.setVisible(true);
            }else{
                List<RDV> rdvNow = new ArrayList(Noyeau.rendezVousDuClientX(nom.getText(),prenom.getText(),telephone.getText()));
                if (rdvNow.size() != 0) {
                    Client c;


                    for (RDV rn : rdvNow
                            ) {
                        c = Noyeau.patients.get(rn.getClient_Id());
                        liste.getItems().add("RDV N°" + Noyeau.rdvs.indexOf(rn) + ", pour le patient :" + c.getNom() + " " + c.getPrenom());

                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initOwner(Main.stage);
                    alert.setTitle("Filtre Vide");
                    alert.setHeaderText("Aucun Rendez-vous pour ce client !\nVerifier l'ordre des entrées");
                    alert.setContentText("nom :"+nom.getText()+"\nprenom :"+prenom.getText()+"\ntelephone "+telephone.getText());
                    alert.showAndWait();
                }
            }

            Noyeau.afficherPat();
            Noyeau.afficherRDV();
        }
    }


    public void impressionClique(){
        String selectedItem = (String) liste.getSelectionModel().getSelectedItem();
        if (selectedItem != (null)) {
            int debut = selectedItem.lastIndexOf("°");
            int fin = selectedItem.lastIndexOf(",");
            String Num = selectedItem.substring(debut + 1, fin);
            int rdvid = Integer.parseInt(Num);

            Noyeau.rdvs.get(rdvid).imprimerRDV();
        }
    }


    public void modifierClique(){
        Stage stage = Main.stage;
        Parent root;
        String selectedItem = (String) liste.getSelectionModel().getSelectedItem();
        if (selectedItem!=(null)) {
            Noyeau.modifPage = 2 ;
            int debut = selectedItem.lastIndexOf("°");
            int fin = selectedItem.lastIndexOf(",");
            String Num = selectedItem.substring(debut + 1, fin);
            int index = Integer.parseInt(Num);
            try {
                root = FXMLLoader.load(getClass().getResource("modifier.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle(String.format("modification de RDV :%d", index));
                stage.show();
            } catch (IOException e) {
            }
        }
    }

    public  void informatioClique(){
        String selectedItem = (String) liste.getSelectionModel().getSelectedItem();
        if (selectedItem != (null)) {
            int debut = selectedItem.lastIndexOf("°");
            int fin = selectedItem.lastIndexOf(",");
            String Num = selectedItem.substring(debut + 1, fin);
            int rdvid = Integer.parseInt(Num);
            RDV r = Noyeau.rdvs.get(rdvid) ;
            Client c = Noyeau.patients.get(r.getClient_Id()) ;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initOwner(Main.stage);
            alert.setTitle("Information");
            alert.setHeaderText("Information du RDV N° \n"+rdvid);
            alert.setContentText("Date :"+r.getDate()+"\nObjet :"+r.getObjet()+"\nClient :"+c.getNom()+" "+c.getPrenom()+"\nTelephone :"+c.getTelephone()+
                    "\nMail :"+c.getMail()+"\nAdresse :"+c.getAdresse()+"\nInformation medicale :"+c.getInfo_medicale());
            alert.showAndWait() ;
        }
    }



    private boolean verifierNumTel () {
          if (telephone.getText().charAt(0) != '0') return false;
            else {
                if ((telephone.getText().charAt(1) != '5') && (telephone.getText().charAt(1) != '6') && (telephone.getText().charAt(1) != '7'))
                    return false;
                else {
                    if (telephone.getText().length() != 10) return false;
                    else {

                        try {
                            IntegerStringConverter x = new IntegerStringConverter();
                            x.fromString(telephone.getText());
                            return true;
                        } catch (NumberFormatException e) {
                            return false;
                        }
                    }
                }
            }
        }
}
