package sample;

import java.io.Serializable;
import java.util.Objects;

public class Client implements Serializable {

    static int nb_Client = 0 ;
    private int client_id ;
    private String nom;
    private String prenom;
    private String adresse;
    private String telephone;
    private String mail;
    private String info_medicale;

    public Client(String nom,String prenom,String num_tel,String adresse,String mail,String info){
        this.nom = nom;
        this.prenom = prenom ;
        this.telephone =num_tel ;
        this.adresse= adresse ;
        this.mail = mail ;
        this.info_medicale = info;
        client_id = nb_Client ;
        nb_Client++ ;
    }

    //Fct pour determiner si le patient et le mm verifiant le nom,prenom, telphone
    public boolean isItMe(String nom,String prenom,String tphn){
        if(!this.nom.equals(nom)) return false ;
        else if(!this.prenom.equals(prenom)) return false ;
            else if(!this.telephone.equals(tphn)) return false ;
                    else return true ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return client_id == client.client_id;
    }



    @Override
    public int hashCode() {

        return Objects.hash(client_id);
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getMail() {
        return mail;
    }

    public String getInfo_medicale() {
        return info_medicale;
    }
}
