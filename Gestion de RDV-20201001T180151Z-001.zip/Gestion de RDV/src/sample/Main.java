package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class Main extends Application {

    public  static  Stage stage;

    @Override
    public void start(Stage primaryStage) throws Exception{

        Parent root = FXMLLoader.load(getClass().getResource("noyeau.fxml"));
        primaryStage.setTitle("RDV management");
        stage=primaryStage;
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
        root.requestFocus();

    }


    public static void main(String[] args) {

      try{
            FileInputStream readData = new FileInputStream("rendezvous.ser");
            ObjectInputStream readStream = new ObjectInputStream(readData);
            Noyeau.rdvs = (ArrayList<RDV>) readStream.readObject();
            readStream.close();

            readData= new FileInputStream("patients.ser");
            readStream = new ObjectInputStream(readData);
            Noyeau.patients = (ArrayList<Client>) readStream.readObject();
            readStream.close();


            System.out.println(Noyeau.patients.toString());
            System.out.println(Noyeau.rdvs.toString());
        }catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }


        Noyeau.afficherRDV();
        Noyeau.afficherPat();
        launch(args);


        try{
            FileOutputStream writeData = new FileOutputStream("rendezvous.ser");
            ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
            writeStream.writeObject(Noyeau.rdvs);
            writeStream.flush();
            writeStream.close();

            writeData = new FileOutputStream("patients.ser");
            writeStream = new ObjectOutputStream(writeData);
            writeStream.writeObject(Noyeau.patients);
            writeStream.flush();
            writeStream.close();

        }catch (IOException e) {
            e.printStackTrace();
        }
    }



}
