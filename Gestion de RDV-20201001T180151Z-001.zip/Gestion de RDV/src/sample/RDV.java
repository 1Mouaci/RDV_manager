package sample;

import javax.print.*;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import java.awt.*;
import java.io.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;


public class RDV implements Serializable{
    static int nb_Rdv =0;
    private LocalDate date;
    private String objet;
    private int client_Id ;
    private int rdv_Id;

    public RDV (LocalDate date, String objet, int id)
    {
        this.date = LocalDate.of(date.getYear(),date.getMonth(),date.getDayOfMonth());
        this.objet = objet ;
        this.client_Id = id ;
        this.rdv_Id = nb_Rdv ;
        nb_Rdv++ ;
    }

    public RDV(RDV r){
        this.date = LocalDate.of(r.date.getYear(),r.date.getMonth(),r.date.getDayOfMonth());
        this.objet = r.objet ;
        this.client_Id = r.client_Id ;
        this.rdv_Id = r.rdv_Id ;
    }

    public int getrdv_Id() {
        return rdv_Id;
    }

    public int getClient_Id() {
        return client_Id;
    }

    public static int getNb_Rdv() {
        return nb_Rdv;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getObjet() {
        return objet;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RDV rdv = (RDV) o;
        return rdv_Id == rdv.rdv_Id;
    }

    @Override
    public int hashCode() {

        return Objects.hash(rdv_Id);
    }

    public void modifier_RDV(LocalDate date,String objet){
        if(date!= null){
            this.date = LocalDate.of(date.getYear(),date.getMonth(),date.getDayOfMonth());
        }
        if(!objet.equals("")){
            this.objet = objet ;
        }
    }

    public void imprimerRDV(){
        //on a un seule fichier qu'on imprime pour chaque RDV a chaque fois on ecrase ses donnée en faveur des nouvezau
        String nomFichier = ("C:\\RDV\\Rdv.txt");

        //construire le fichier ::
        try{
            File ff=new File(nomFichier); // définir l'arborescence
            ff.createNewFile();
            FileWriter ffw=new FileWriter(ff);
            ffw.write("****** client ID :"+this.client_Id+"*******\n");  // écrire une ligne dans le fichier resultat.txt
            ffw.write("\n"); // forcer le passage à la ligne
            ffw.write("****** Rendez-vous ID :"+this.rdv_Id+"*******\n") ;
            ffw.write("****** datee le :"+this.date.toString()+"*******\n") ;
            ffw.write("Objet :"+this.objet);
            ffw.write("\n"); // forcer le passage à la ligne
            ffw.close(); // fermer le fichier à la fin des traitements

            Desktop desk = Desktop.getDesktop();
            desk.open(new File(nomFichier));

        } catch (Exception ignored) {}


        //creation de l'objet FileInputStream
        FileInputStream fis = null;

        PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
        DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;


        // lister les imprimantes qui supportent ce flavor
        PrintService printService[] = PrintServiceLookup.lookupPrintServices(flavor, pras);
        PrintService defaultService = PrintServiceLookup.lookupDefaultPrintService();
        // choix de l'imprimante
        PrintService service = ServiceUI.printDialog(null, 200, 200, printService, defaultService, flavor, pras);
        if (service != null) {
            DocPrintJob job = service.createPrintJob();
            try {

                fis = new FileInputStream(new File(nomFichier));
                DocAttributeSet das = new HashDocAttributeSet();
                Doc doc = new SimpleDoc(fis, flavor, das);



                // lancement de l'impression
                job.print(doc, pras);
            } catch (PrintException | IOException ex) {
                ex.printStackTrace();
            } finally{
                try{
                    if(fis!=null){
                        fis.close();
                    }
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public void setClient_Id(int client_Id) {
        this.client_Id = client_Id;
    }
}
