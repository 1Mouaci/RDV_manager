package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;


import java.io.IOException;
import java.util.List;

import static sample.Noyeau.rdvs;

public class ListeRdv extends Stage {

    public ScrollPane s;

    public  ListeRdv(List<RDV> rdv) {

        IntegerStringConverter converter = new IntegerStringConverter();
        this.s = new ScrollPane();
        VBox liste = new VBox(10);
        Button boutons[][] = new Button[rdv.size()][2];
        Label label[] = new Label[rdv.size()];
        int i = 0;

        for (RDV r : rdv
                ) {
            Client c = Noyeau.clientDeRdv(r);
            label[i] = new Label() ;
            label[i].setText("le rendez vous N° =" + converter.toString(rdvs.indexOf(r)) +
                    "\nla date de :" + r.getDate().toString() + "\nde monsieur \n" +
                    c.getNom() + " " + c.getPrenom());

            boutons[i][0] = new Button("modifier");
            boutons[i][1] = new Button("imprimer");

            final int index = Noyeau.rdvs.indexOf(r);
            boutons[i][0].setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent actionEvent) {
                    Stage stage = Main.stage;
                    Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("modifier.fxml"));
                        stage.setScene(new Scene(root));
                        stage.setTitle(String.format("modification de RDV %d", index));
                        stage.show();
                    } catch (IOException e) {
                    }
                }
            });

            boutons[i][1].setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent actionEvent) {
                    r.imprimerRDV();
                }
            });
            HBox h = new HBox(10,label[i],boutons[i][0],boutons[i][1]);
            liste.getChildren().add(h) ;
        }

        s.setContent(liste);
        this.setScene(new Scene(s));
    }

}
