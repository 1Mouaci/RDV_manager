package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class Modifier {
    public TextArea obj;
    public DatePicker date;

    public void annulerModificationClique() {
        Stage stage = Main.stage;
        Parent root;
        try {
            if (Noyeau.modifPage == 1 ) {
                root = FXMLLoader.load(getClass().getResource("noyeau.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("RDV Manager");
            }else {
                root = FXMLLoader.load(getClass().getResource("filtrage.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("RDV Filtre");
            }
            stage.show();
            root.requestFocus();
        } catch (IOException e) {
        }
    }


    public void modifierClique(){
        Stage stage = Main.stage;
        String titre = stage.getTitle() ;
        int debut = titre.lastIndexOf(":");
        String Num = titre.substring(debut + 1);
        int index = Integer.parseInt(Num);
        RDV r = Noyeau.rdvs.get(index) ;

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initOwner(Main.stage);
        alert.setTitle("Prise de RDV N° " + Noyeau.rdvs.size());
        alert.setHeaderText("Voulez vous Modifier le RDV "+index+"?");
        alert.setContentText("Date :"+r.getDate().getDayOfMonth() + " " + r.getDate().getMonth() + " " + r.getDate().getYear()+" vers " +date.getValue().getDayOfMonth() + " " + date.getValue().getMonth() + " " + date.getValue().getYear()+
        "\nNouveau Objet :\n"+obj.getText());
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            if (!date.getValue().toString().equals("")) {
                r.setDate(date.getValue());
                date.setValue(null);
            }
            if (!obj.getText().equals("")) {
                r.setObjet(obj.getText());
                obj.clear();

            }
        }

        Noyeau.afficherPat();
        Noyeau.afficherRDV();
    }

    public void supprimerClique(){
        Stage stage = Main.stage;
        Parent root ;
        String titre = stage.getTitle() ;
        int debut = titre.lastIndexOf(":");
        String Num = titre.substring(debut + 1);
        int index = Integer.parseInt(Num);
        RDV r = Noyeau.rdvs.get(index) ;
        Client c = Noyeau.patients.get(r.getClient_Id()) ;

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initOwner(Main.stage);
        alert.setTitle("Prise de RDV N° " + Noyeau.rdvs.size());
        alert.setHeaderText("Voulez vous confirmer la suppression du RDV "+index+"?");
        alert.setContentText("Date :"+r.getDate()+"\nObjet :"+r.getObjet()+"\nClient :"+c.getNom()+" "+c.getPrenom()+"\nTelephone :"+c.getTelephone()+
                "\nMail :"+c.getMail()+"\nAdresse :"+c.getAdresse()+"\nInformation medicale :"+c.getInfo_medicale());
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            r.setDate(null);
            r.setClient_Id(-1);
            try {
                if (Noyeau.modifPage == 1 ) {
                    root = FXMLLoader.load(getClass().getResource("noyeau.fxml"));
                    stage.setScene(new Scene(root));
                    stage.setTitle("RDV Manager");
                }else {
                    root = FXMLLoader.load(getClass().getResource("filtrage.fxml"));
                    stage.setScene(new Scene(root));
                    stage.setTitle("RDV Filtre");
                }
                stage.show();
                root.requestFocus();
            } catch (IOException e) {
            }
        }
    }
}
