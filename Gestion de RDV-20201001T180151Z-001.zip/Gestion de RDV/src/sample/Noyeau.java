package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Noyeau implements Initializable {
    static List<Client> patients =  new ArrayList<Client>();
    static List<RDV> rdvs =  new ArrayList<RDV>();

    static int modifPage ;// pour savoir si on desire modifier un RDV du jour wla d'apres le filtrage


    public javafx.scene.control.Button filtre;
    public Button creerdv;
    public ListView liste;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // lire les donne des rdcvs w patients deja enregistree dans un fichier pour les initialisé

        List<RDV> rdvNow = new ArrayList(this.rendezVousDuDateX(LocalDate.now())) ;
        Client c ;
        System.out.println(rdvNow.size()+" ;"+patients.size());

        for (RDV rn : rdvNow
             ) {
            c = patients.get(rn.getClient_Id()) ;
            liste.getItems().add("RDV N°"+rdvs.indexOf(rn)+", pour le patient :"+c.getNom()+" "+c.getPrenom()) ;

        }

        this.afficherPat();
        this.afficherRDV();
    }

    //methodes des boutons*****************************************************************************************
    public void impressionRDV(){
        String selectedItem = (String) liste.getSelectionModel().getSelectedItem();
        if (selectedItem != (null)) {
            int debut = selectedItem.lastIndexOf("°");
            int fin = selectedItem.lastIndexOf(",");
            String Num = selectedItem.substring(debut + 1, fin);
            int rdvid = Integer.parseInt(Num);

            rdvs.get(rdvid).imprimerRDV();
        }
    }

    public void modifierRDV(){
        Stage stage = Main.stage;
        Parent root;
        String selectedItem = (String) liste.getSelectionModel().getSelectedItem();
        if (selectedItem!=(null)) {
            modifPage = 1;
            int debut = selectedItem.lastIndexOf("°");
            int fin = selectedItem.lastIndexOf(",");
            String Num = selectedItem.substring(debut + 1, fin);
            int index = Integer.parseInt(Num);
            try {
                root = FXMLLoader.load(getClass().getResource("modifier.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle(String.format("modification de RDV :%d", index));
                stage.show();
            } catch (IOException e) {
            }
        }
    }


    public void creeRDVClique(){
        Stage stage = Main.stage ;
        Parent root ;
        try {
            root = FXMLLoader.load(getClass().getResource("typePatient.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle(" Login  ");
            stage.show();
        }
        catch (IOException e){}
    }

    public void filtreCLique(){
        Stage stage = Main.stage ;
        Parent root ;
        try {
            root = FXMLLoader.load(getClass().getResource("filtrage.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle(" Filtre ");
            stage.show();
        }
        catch (IOException e){}
    }


    public  void informatioClique(){
        String selectedItem = (String) liste.getSelectionModel().getSelectedItem();
        if (selectedItem != (null)) {
            int debut = selectedItem.lastIndexOf("°");
            int fin = selectedItem.lastIndexOf(",");
            String Num = selectedItem.substring(debut + 1, fin);
            int rdvid = Integer.parseInt(Num);
            RDV r = rdvs.get(rdvid) ;
            Client c = patients.get(r.getClient_Id()) ;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initOwner(Main.stage);
            alert.setTitle("Information");
            alert.setHeaderText("Information du RDV N° \n"+rdvid);
            alert.setContentText("Date :"+r.getDate()+"\nObjet :"+r.getObjet()+"\nClient :"+c.getNom()+" "+c.getPrenom()+"\nTelephone :"+c.getTelephone()+
            "\nMail :"+c.getMail()+"\nAdresse :"+c.getAdresse()+"\nInformation medicale :"+c.getInfo_medicale());
            alert.showAndWait() ;
        }
    }
    /**methode utilitaire ::
     * **********************
     * ************************
     * ***********************/
    public static Client clientDeRdv(RDV rdv){
        return patients.get(rdv.getClient_Id());
    }
    
    
    public static Client clientNPT(String nom, String prenom,String telephone){

        Client pat= null ;
        for (Client patient:patients
             ) {
            if (patient.isItMe(nom, prenom, telephone)) pat =patient;
        }

        return pat ;
    }

    public static List<RDV> rendezVousDuDateX(LocalDate d) {
        List <RDV> listeRendezVDuHour = new ArrayList<>() ;
        for (RDV r: rdvs
             ) {
            if (r.getDate().equals(d)) {RDV ri = new RDV(r) ;
            listeRendezVDuHour.add(ri) ;}
        }
        return listeRendezVDuHour;
    }

    public static List<RDV> rendezVousDuClientX(String nom,String prenom,String telephone) {
        List <RDV> listeRendezVDuHour = new ArrayList<>() ;
        int id = Noyeau.patients.indexOf(clientNPT(nom, prenom, telephone)) ;
        for (RDV r: rdvs
                ) {

            if (r.getClient_Id() == id) {RDV ri = new RDV(r) ;
                listeRendezVDuHour.add(ri) ;}
        }
        return listeRendezVDuHour;
    }




    public static void afficherPat(){
        for ( Client c: patients
             ) {
            System.out.println(c.getNom()+" "+c.getPrenom()+" "+patients.indexOf(c)+ " "+c.getTelephone());
            System.out.println("\n");
        }
    }

    public static void afficherRDV(){
        for ( RDV r: rdvs
                ) {
            System.out.println(r.getrdv_Id()+" "+r.getDate().toString()+" "+r.getObjet()+" "+r.getClient_Id());
            System.out.println("\n");
        }
    }




}
