package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Optional;

public class Typepatient {

    public TextField nom;
    public TextField prenom;
    public TextField telephone;
    public TextField adresse;
    public TextField mail;
    public TextArea info;

    public DatePicker date;
    public TextArea objet;


    public RadioButton nouveua;
    public RadioButton ancien;
    public TextField erreur;

    public void oldPatient() {
        adresse.setVisible(false);
        mail.setVisible(false);
        info.setVisible(false);
    }


    public void newPatient() {
        adresse.setVisible(true);
        mail.setVisible(true);
        info.setVisible(true);
    }

    public void annulerInscriptionClique() {
        Stage stage = Main.stage;
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("noyeau.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle(" Bienvenue");
            stage.show();
            root.requestFocus();
        } catch (IOException e) {
        }
    }

    public void creeRDVClique() {
        Client patient;
        RDV r;
        int id;

        erreur.setStyle("-fx-text-fill: #fd001e");
        if (nom.getText().equals("") || prenom.getText().equals("") || telephone.getText().equals("")) {
            erreur.setText("remplire les donnée completement");
            erreur.setVisible(true);
        } else {
            if (!this.verifierNumTel()) {
                erreur.setText("Verifier le numero de telephone ");
                erreur.setVisible(true);
            } else {
                if (!this.verifierDate()) {
                    erreur.setText("Verifier la date de rendez-vous ");
                    erreur.setVisible(true);
                } else {
                    if (nouveua.isSelected()) {
                        if (Noyeau.patients.indexOf(Noyeau.clientNPT(nom.getText(), prenom.getText(), telephone.getText()))==-1) {
                            patient = new Client(nom.getText(), prenom.getText(), telephone.getText(), adresse.getText(), mail.getText(), info.getText());
                            Noyeau.patients.add(patient);
                            id = Noyeau.patients.indexOf(patient);
                        }else {
                            ancien.setSelected(true);
                            id = Noyeau.patients.indexOf(Noyeau.clientNPT(nom.getText(), prenom.getText(), telephone.getText()));
                        }
                    } else {
                        patient = Noyeau.clientNPT(nom.getText(), prenom.getText(), telephone.getText());
                        if (patient == null) {
                            erreur.setText("le client referee n'existe pas");
                            nouveua.setSelected(true);
                            erreur.setVisible(true);
                            return;
                        } else id = Noyeau.patients.indexOf(patient);
                    }

                    if (date.toString().equals("") || objet.getText().equals("")) {
                        erreur.setText("veuillez vous remplir les champs necessaire");
                        erreur.setVisible(true);
                    } else {
                        erreur.setStyle("-fx-text-fill: #1b8325");
                        erreur.setText("Le rendez vous est pris");
                        erreur.setVisible(true);

                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.initOwner(Main.stage);
                        alert.setTitle("Prise de RDV N° " + Noyeau.rdvs.size());
                        alert.setHeaderText("Voulez vous imprimer le RDV? \nSi vous voulez le modifier presse sur annuler! ");
                        alert.setContentText("votre RDV pour : Ms/Mme " + nom.getText() + " " + prenom.getText() + "\n\n" + "Le " + date.getValue().getDayOfMonth() + " " + date.getValue().getMonth() + " " + date.getValue().getYear() + " \nObjet :\n" + objet.getText());
                        Optional<ButtonType> result = alert.showAndWait();
                        if (result.get() == ButtonType.CANCEL) {
                            Noyeau.patients.remove(id) ;
                            erreur.setText("Vueillez modifier le RDV svp");
                        } else {
                            r = new RDV(date.getValue(), objet.getText(), id);
                            Noyeau.rdvs.add(r);
                            erreur.setVisible(false);
                            erreur.setText("remplire les donnée completement");
                            date.setValue(null);
                            nom.clear();
                            prenom.clear();
                            telephone.clear();
                            adresse.clear();
                            mail.clear();
                            info.clear();
                            objet.clear();
                            nouveua.setSelected(true);
                            ancien.setSelected(false);
                            r.imprimerRDV();
                            Noyeau.afficherRDV();
                            Noyeau.afficherPat();

                        }
                    }
                }
            }
        }
    }




        private boolean verifierDate(){
            if(date.getValue().isBefore(LocalDate.now())) return false ;
            else return true ;
        }

        private boolean verifierAdresse () {
            if (adresse.getText().equals("")) return false;
            else {
                if (adresse.getText().charAt(adresse.getText().length() - 1) == ',') return false;
                else if (adresse.getText().charAt(0) == ',') return false;
                else return true;
            }
        }

        private boolean verifierNumTel () {
            if (telephone.getText().charAt(0) != '0') return false;
            else {
                if ((telephone.getText().charAt(1) != '5') && (telephone.getText().charAt(1) != '6') && (telephone.getText().charAt(1) != '7'))
                    return false;
                else {
                    if (telephone.getText().length() != 10) return false;
                    else {

                        try {
                            IntegerStringConverter x = new IntegerStringConverter();
                            x.fromString(telephone.getText());
                            return true;
                        } catch (NumberFormatException e) {
                            return false;
                        }
                    }
                }
            }
        }
    
}

    

